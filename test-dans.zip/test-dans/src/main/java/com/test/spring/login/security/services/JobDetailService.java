package com.test.spring.login.security.services;

import java.util.HashMap;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.test.spring.login.util.HttpComponentGET;
import com.test.spring.login.util.HttpComponentGETdetail;

@Service
public class JobDetailService {
	
	public JsonNode hitAPI(String id) {
		
		HttpComponentGETdetail reqGetApi = new HttpComponentGETdetail();
		
		JsonNode resp = reqGetApi.SendToHttpGetWithReffno(id);
		return resp;
	}

}
