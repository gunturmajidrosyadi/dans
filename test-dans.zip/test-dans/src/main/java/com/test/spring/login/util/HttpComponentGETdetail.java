package com.test.spring.login.util;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jackson.type.TypeReference;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class HttpComponentGETdetail {

	private Logger log = LogManager.getLogger(HttpComponentGETdetail.class);
	private String ip;
	private String port;
	private String path;
	private int rto;
	private int cto;

	public HttpComponentGETdetail() {
	}

	public JsonNode SendToHttpGetWithReffno(String id) {
		
		rto = 90000;
		cto = 90000;

		ObjectMapper mapper = new ObjectMapper();
		try {
			String url = "http://dev3.dansmultipro.co.id/api/recruitment/positions/" + id;
			
			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
//			con.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
			con.setReadTimeout(rto);
			con.setConnectTimeout(cto);
			con.setDoOutput(true);
			con.setDoInput(true);
			con.setRequestMethod("GET");
			
			log.info("Get Connection : " + url);

			InputStream inn = new BufferedInputStream(con.getInputStream());
			String result = org.apache.commons.io.IOUtils.toString(inn, "UTF-8");
			log.info("GET Response -> " + result);

			inn.close();
			con.disconnect();
			JsonNode responsebuild = mapper.readTree(result);
			
			return responsebuild;
			
		} catch (Exception e2) {
			log.error(e2.getMessage(), e2);
		}

		return null;
	}


	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public int getRto() {
		return rto;
	}

	public void setRto(int rto) {
		this.rto = rto;
	}

	public int getCto() {
		return cto;
	}

	public void setCto(int cto) {
		this.cto = cto;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

}
