package com.test.spring.login.controllers;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;
import com.test.spring.login.security.services.JobDetailService;
import com.test.spring.login.security.services.JobListService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/test")
public class TestController {
	
	@Autowired
	JobListService jobListService;
	
	@Autowired
	JobDetailService jobDetailService;

  @GetMapping("/detailjob/{id}")
  @PreAuthorize("hasRole('USER') or hasRole('MODERATOR') or hasRole('ADMIN')")
  public JsonNode userAccess(@PathVariable("id")String id){
	  
	  JsonNode responseJson = jobDetailService.hitAPI(id);
	    return responseJson;
  }

  @GetMapping("/listjob")
  @PreAuthorize("hasRole('USER') or hasRole('MODERATOR') or hasRole('ADMIN')")
  public JsonNode moderatorAccess() {	  
	  JsonNode responseJson = jobListService.hitAPI();
	    return responseJson;
  }

}
