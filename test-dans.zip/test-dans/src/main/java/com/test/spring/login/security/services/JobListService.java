package com.test.spring.login.security.services;

import java.util.HashMap;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.test.spring.login.util.HttpComponentGET;

@Service
public class JobListService {
	
	public JsonNode hitAPI() {
		
		HttpComponentGET reqGetApi = new HttpComponentGET();
		
		JsonNode resp = reqGetApi.SendToHttpGetWithReffno();
		return resp;
	}

}
